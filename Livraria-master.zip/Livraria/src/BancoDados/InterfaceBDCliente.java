/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BancoDados;

import Excecoes.ClienteContainsException;
import Excecoes.ClienteInvalidoException;
import Negocio.Cliente;
import java.sql.SQLException;
import java.util.Set;

/**
 *
 * @author 01124690
 */
public interface InterfaceBDCliente {
    
    public void cadastrar(Cliente c)throws ClassNotFoundException, SQLException;
    public void remover (Cliente c)throws SQLException,ClienteInvalidoException;
    public Set<Cliente> getLista(String pesquisa) throws SQLException, ClienteInvalidoException;
    
}
