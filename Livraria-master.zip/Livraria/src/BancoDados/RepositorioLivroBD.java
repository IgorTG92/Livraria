/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BancoDados;

import Excecoes.ClienteInvalidoException;
import Excecoes.LivroInvalidoException;
import Negocio.Cliente;
import Negocio.Livro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 01126270
 */
public class RepositorioLivroBD implements InterfaceBDLivro {

    private Connection conexao;

    public RepositorioLivroBD() throws SQLException, ClassNotFoundException {
        this.conexao = Conexao.conectar();
    }

    @Override
    public void cadastrar(Livro l) throws ClassNotFoundException, SQLException {

        String insert = " insert into livro (nome_livro, genero_livro, codigo_livro, , valor_livro, paginas_livro)";

        PreparedStatement stmt = conexao.prepareStatement(insert);

        stmt.setString(1, l.getNome());
        stmt.setString(2, l.getGenero());
        stmt.setInt(3, l.getCodigo());
        stmt.setDouble(4, l.getValor());
        stmt.setInt(5, l.getQtdPaginas());

        stmt.execute();
        stmt.close();
    }

    @Override
    public void remover(Livro l) throws SQLException, ClienteInvalidoException {
        
        String remover = "delete from Livro where codigo_Livro";
        PreparedStatement stmt = conexao.prepareStatement(remover);

        stmt.setInt(1, l.getCodigo());
        stmt.execute();
        stmt.close();
    }

    @Override
    public Set<Livro> getLista(String pesquisa) throws SQLException, ClienteInvalidoException {

        String sql = "select * from livro where nome_livro";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setString(1, pesquisa);
        ResultSet rs = stmt.executeQuery();

        Set<Livro> livros = new HashSet<Livro>();

        while (rs.next()) {

            try {
                Livro l = new Livro();
                
                l.setNome(rs.getString("nome_Livro"));
                l.setCodigo(rs.getInt("codigo_Livro"));
                l.setGenero(rs.getString("genero_livro"));
                l.setValor(rs.getDouble("valor_livro"));
                l.setQtdPaginas(rs.getInt("qtdPeginas_Livro"));
            } catch (LivroInvalidoException ex) {
                Logger.getLogger(RepositorioLivroBD.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        rs.close();
        stmt.close();
        return livros;
    }

}
