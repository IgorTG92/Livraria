/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Excecoes.FuncionarioContainsException;
import Negocio.Funcionario;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Win7
 */
public class RepFuncionario implements InterfaceFuncionario {

    private Set<Funcionario> funcionarios;

    public RepFuncionario() {
        this.funcionarios = new HashSet<Funcionario>();
    }

    @Override
    public void cadastrar(Funcionario f) throws FuncionarioContainsException {
        if (this.funcionarios.contains(f)) {
            throw new FuncionarioContainsException("FUNCIONÁRIO JÁ CADASTRADO!");
        } else {
            this.funcionarios.add(f);
        }
    }

    @Override
    public void remover(Funcionario f) throws FuncionarioContainsException {
        if (this.funcionarios.contains(f)) {
            this.funcionarios.remove(f);
        } else {
            throw new FuncionarioContainsException("FUNCIONÁRIO JÁ REMOVIDO!");
        }
    }

    @Override
    public void listar() {
        for (Funcionario f : this.funcionarios) {
            System.out.println(f.toString());

        }
    }

}
