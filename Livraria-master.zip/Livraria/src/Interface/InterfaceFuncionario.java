/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Excecoes.FuncionarioContainsException;
import Negocio.Funcionario;

/**
 *
 * @author Win7
 */
public interface InterfaceFuncionario {
    
    public void cadastrar(Funcionario f)throws FuncionarioContainsException;
    public void remover (Funcionario f)throws FuncionarioContainsException;
    public void listar();
    
    
}
