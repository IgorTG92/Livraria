/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Excecoes.ClienteInvalidoException;
import java.util.Objects;
import javax.swing.JTextField;

/**
 *
 * @author Win7
 */
public class Cliente {

    private String nome;
    private String cpf;
    private String endereco;
    private String email;
    private String telefone;

    public Cliente(String nome, String cpf, String endereco, String email, String telefone) throws ClienteInvalidoException {
        this.setNome(nome);
        this.setCpf(cpf);
        this.setEndereco(endereco);
        this.setEmail(email);
        this.setTelefone(telefone);
    }

    public Cliente(String nome, String cpf) throws ClienteInvalidoException {
      this.setNome(nome);
      this.setCpf(cpf);
    }

    public Cliente() {
        
    }

  
    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setNome(String nome) throws ClienteInvalidoException {
        if (nome == null || nome.isEmpty()) {
            throw new ClienteInvalidoException("NOME INVÁLIDO, REDIGITE!");
        } else {
            this.nome = nome;
        }
    }

    public void setCpf(String cpf) throws ClienteInvalidoException {
        if (cpf == null || cpf.isEmpty()) {
            throw new ClienteInvalidoException("CPF INVÁLIDO, REDIGITE!");
        } else {
            this.cpf = cpf;
        }
    }

    public void setEndereco(String endereco) throws ClienteInvalidoException {
        if (endereco == null || endereco.isEmpty()) {
            throw new ClienteInvalidoException("ENDEREÇO INVÁLIDO, REDIGITE!");
        } else {
            this.endereco = endereco;
        }
    }

    public void setEmail(String email) throws ClienteInvalidoException {
        if (email == null || email.isEmpty()) {
            throw new ClienteInvalidoException("E-MAIL INVÁLIDO, REDIGITE!");
        } else {
            this.email = email;
        }
    }

    public void setTelefone(String telefone) throws ClienteInvalidoException{
        if(telefone == null || telefone.isEmpty())
            throw new ClienteInvalidoException("TELEFONE INVÁLIDO, REDIGITE!");
            else
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nome=" + nome + ", cpf=" + cpf + ", endereco=" + endereco + ", email=" + email + ", telefone=" + telefone + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 29 * hash + Objects.hashCode(this.nome);
        hash = 29 * hash + Objects.hashCode(this.cpf);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        if (!Objects.equals(this.cpf, other.cpf)) {
            return false;
        }
        return true;
    }

  

 
    

}
