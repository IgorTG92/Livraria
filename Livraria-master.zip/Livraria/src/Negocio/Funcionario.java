/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Excecoes.FuncionarioInvalidoException;
import java.util.Objects;

/**
 *
 * @author Win7
 */
public class Funcionario {

    private String nome;
    private int codigo;
    private String profissao;

    public Funcionario(String nome, int codigo, String profissao) throws FuncionarioInvalidoException {
        this.nome = nome;
        this.codigo = codigo;
        this.profissao = profissao;
    }

    public String getNome() {
        return nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getProfissao() {
        return profissao;
    }

    public void setNome(String nome) throws FuncionarioInvalidoException {
        if (nome == null || nome.isEmpty()) {
            throw new FuncionarioInvalidoException("NOME INVÁLIDO, REDIGITE!");
        } else {
            this.nome = nome;
        }
    }

    public void setCodigo(int codigo) throws FuncionarioInvalidoException {
        if (codigo < 0) {
            throw new FuncionarioInvalidoException("CÓDIGO MENOR QUE ZERO, REDIGITE!");
        } else {
            this.codigo = codigo;
        }
    }

    public void setProfissao(String profissao) throws FuncionarioInvalidoException {
        if (profissao == null || profissao.isEmpty()) {
            throw new FuncionarioInvalidoException("PROFISSÃO INVÁLIDA, REDIGITE!");
        } else {
            this.profissao = profissao;
        }
    }

    @Override
    public String toString() {
        return "Funcionario{" + "nome=" + nome + ", codigo=" + codigo + ", profissao=" + profissao + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 73 * hash + Objects.hashCode(this.nome);
        hash = 73 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Funcionario other = (Funcionario) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        return true;
    }

}
