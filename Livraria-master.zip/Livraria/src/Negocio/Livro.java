/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocio;

import Excecoes.LivroInvalidoException;
import java.util.Objects;
import javax.swing.JTextField;

/**
 *
 * @author Win7
 */
public class Livro {

    private String nome;
    private String genero;
    private int codigo;
    private double valor;
    private int qtdPaginas;

    public Livro(String nome, String genero, int codigo, double valor, int qtdPaginas) throws LivroInvalidoException {
        this.setNome(nome);
        this.setGenero(genero);
        this.setCodigo(codigo);
        this.setValor(valor);
        this.setQtdPaginas(qtdPaginas);
    }

    public Livro(String nome, int codigo) throws LivroInvalidoException {
        this.setNome(nome);
        this.setCodigo(codigo);
    }

    public Livro() {

    }

    public String getNome() {
        return nome;
    }

    public String getGenero() {
        return genero;
    }

    public int getCodigo() {
        return codigo;
    }

    public double getValor() {
        return valor;
    }

    public int getQtdPaginas() {
        return qtdPaginas;
    }

    public void setNome(String nome) throws LivroInvalidoException {
        if (nome == null || nome.isEmpty()) {
            throw new LivroInvalidoException("NOME INVÁLIDO,REDIGITE");
        } else {
            this.nome = nome;
        }
    }

    public void setGenero(String genero) throws LivroInvalidoException {
        if (genero == null || genero.isEmpty()) {
            throw new LivroInvalidoException("GÊNERO INVÁLIDO,REDIGITE!");
        } else {
            this.genero = genero;
        }
    }

    public void setCodigo(int codigo) throws LivroInvalidoException {
        if (codigo < 0) {
            throw new LivroInvalidoException("CÓDIGO MENOR QUE ZERO, REDIGITE!");
        } else {
            this.codigo = codigo;
        }
    }

    public void setValor(double valor) throws LivroInvalidoException {
        if (valor < 0) {
            throw new LivroInvalidoException("VALOR MENOR QUE ZERO, REDIGITE!");
        } else {
            this.valor = valor;
        }
    }

    public void setQtdPaginas(int qtdPaginas) throws LivroInvalidoException {
        if (qtdPaginas < 0) {
            throw new LivroInvalidoException("QUANTIDADE MENOR QUE ZERO, REDIGITE!");
        }
        this.qtdPaginas = qtdPaginas;
    }

    @Override
    public String toString() {
        return "Livro{" + "nome=" + nome + ", genero=" + genero + ", codigo=" + codigo + ", valor=" + valor + ", qtdPaginas=" + qtdPaginas + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.nome);
        hash = 59 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Livro other = (Livro) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.nome, other.nome)) {
            return false;
        }
        return true;
    }

}
